# CODEX IMPLEMENTATION BRIEF — Pre-1.0 Documentation Archive

## Objective

Implement the approved documentation-archive classification from:

```text
docs/audits/DOCUMENTATION-ARCHIVE-CLASSIFICATION-REVIEW.md
```

The classification disposition is:

```text
DOCARCH-A — classification is complete; archive implementation can proceed
```

This task converts the current loose historical-document surface into a curated public-release structure while preserving all archived material byte-for-byte.

The implementation must:

1. revalidate the classification against the current `staging` commit;
2. create three immutable deterministic pre-1.0 ZIP archives;
3. create three human-readable `ARCHIVE.md` indexes;
4. archive the classified historical files without altering their bytes;
5. keep the approved current/release-evidence documents loose;
6. perform the 10 approved current-surface link rewrites;
7. preserve the classification report itself loose as the durable rationale;
8. verify counts, hashes, archive contents, and surviving links comprehensively.

Do not change application behavior, version, release identity, deployment, DNS, repository visibility, or indexing.

---

# 1. Read first

Read:

```text
AGENTS.md
docs/CODE-STYLE.md
docs/IMPLEMENTATION-WORKFLOW.md
docs/audits/DOCUMENTATION-ARCHIVE-CLASSIFICATION-REVIEW.md
```

Also read the current loose documents involved in the approved link-rewrite plan before editing them.

Do not modify the supplied implementation brief itself.

---

# 2. Baseline

Before changing anything, record:

```text
branch
HEAD commit
git status --short
tracked file count in docs/implementation-briefs/
tracked file count in docs/audits/
tracked file count in docs/benchmarks/
presence/hash of docs/HISTORY-BENCHMARK.md
```

Expected classified baseline from the audit:

```text
Implementation briefs: 253
Audits: 59
Benchmarks directory: 8
Other historical docs: 1
Total classified at audit time: 321
```

The classification report itself was created after that baseline and must remain loose.

If the repository has gained additional tracked brief/audit/benchmark files since the classification audit, do not silently classify them. Record them and stop unless they are explicitly covered below.

---

# 3. Special treatment of this implementation brief

This archive implementation brief is itself transitional implementation history.

Therefore:

> After this task has successfully completed, this brief should be included byte-for-byte in the **pre-1.0 implementation-history ZIP** and should not remain as a loose implementation brief.

This is an intentional addition to the audit's original 253-file implementation-brief archive set.

Accordingly, if the supplied brief exists at:

```text
docs/implementation-briefs/CODEX_IMPLEMENTATION_BRIEF_pre-1.0-documentation-archive.md
```

or an equivalent clearly identifiable filename under `docs/implementation-briefs/`, include that exact file in the archive.

Expected implementation-history archive count therefore becomes:

```text
254 files
```

if and only if this brief is present there as task input.

Do not modify the brief before archiving it.

If the brief exists only outside the repository working tree, do not invent a repository copy. Report that case and keep the audited archive count at 253.

---

# 4. Keep-loose set

Preserve these classified documents loose.

## Other

```text
docs/HISTORY-BENCHMARK.md
```

## Audits

```text
docs/audits/CROSS-LOCALE-COMPACT-COPY-AND-VISUAL-STATE-REVIEW.md
docs/audits/CROSS-LOCALE-COMPACT-LAYOUT-CAPACITY-REVIEW.md
docs/audits/DEPLOYED-BANDWIDTH-AND-LOCALE-LOADING-REVIEW.md
docs/audits/HSTS-POLICY-REVIEW.md
docs/audits/PUBLIC-REPOSITORY-PUBLICATION-SIGNOFF.md
docs/audits/REFERENCE-OVERLAY-ON-DEMAND-PROTOTYPE.md
docs/audits/RELEASE-CANDIDATE-1.0.0-RC.1-ACCEPTANCE.md
docs/audits/RELEASE-PREPARATION-VERIFICATION.md
docs/audits/RELEASE-READINESS-REVIEW.md
docs/audits/RESOURCE-MATRIX-HEADER-GEOMETRY-VERIFICATION.md
docs/audits/SHARED-ACCESSIBILITY-FOLLOW-UP-RECONCILIATION.md
docs/audits/codex-whole-product-accessibility-audit-final.md
docs/audits/codex-whole-product-security-audit.md
docs/audits/DOCUMENTATION-ARCHIVE-CLASSIFICATION-REVIEW.md
```

Note that the classification report is intentionally added to the retained loose set even though it was not one of the original 59 audits being classified.

## Benchmarks

```text
docs/benchmarks/BROWSER-STORAGE-CAPACITY-BENCHMARK.md
docs/benchmarks/CLOUDFLARE-CSP-SECURITY-HEADERS.md
docs/benchmarks/CLOUDFLARE-STAGING-SMOKE-TEST.md
docs/benchmarks/IMPORT-CAPACITY-BENCHMARK.md
docs/benchmarks/IMPORT-CAPACITY-BROWSER-VALIDATION.md
docs/benchmarks/LOCALIZATION-BUNDLE-AND-STARTUP-REVIEW.md
```

These files must not be included in any archive.

---

# 5. Archive sets

Use the exact archive classifications from:

```text
docs/audits/DOCUMENTATION-ARCHIVE-CLASSIFICATION-REVIEW.md
```

Do not re-decide individual files.

Create:

```text
docs/implementation-briefs/pre-1.0-implementation-history.zip
docs/audits/pre-1.0-superseded-audits.zip
docs/benchmarks/pre-1.0-superseded-benchmarks.zip
```

Expected classified contents before adding this task brief:

```text
implementation-history ZIP: 253 files
superseded-audits ZIP: 46 files
superseded-benchmarks ZIP: 2 files
```

With this implementation brief included as specified above:

```text
implementation-history ZIP: 254 files
```

Do not put `ARCHIVE.md` inside its own ZIP.

Do not put the ZIP itself inside itself.

---

# 6. Preserve archived bytes exactly

For every archived source file:

```text
archive entry payload bytes == original loose file bytes before archival
```

Do not:

```text
normalize line endings
rewrite Markdown links
change encoding
trim whitespace
rename historical files
change historical task identifiers
edit headings
update dates
```

The archive is historical preservation, not cleanup.

All link corrections apply only to the retained loose surface.

---

# 7. Archive path shape

Inside each ZIP, preserve category-relative paths.

Preferred examples:

```text
CODEX_IMPLEMENTATION_BRIEF_foo.md
CODEX_AUDIT_BRIEF_bar.md
```

inside the implementation archive,

and:

```text
BROWSER-STORAGE-RECOVERY-PROBE.md
...
```

inside the audit archive.

Do not embed machine-specific absolute paths.

Do not include a redundant repository-root path such as:

```text
D:/Projects/...
```

A single optional category directory prefix is acceptable only if used consistently, but the simplest form is preferred: archive entries relative to their current category directory.

Record the chosen convention in each `ARCHIVE.md`.

---

# 8. Deterministic ZIP construction

Create deterministic archives.

Requirements:

```text
entries sorted lexicographically by normalized archive path
forward-slash archive paths
stable compression method/settings
stable file metadata
stable timestamps
no machine/user-specific extra fields
no absolute paths
no directory entries unless required
```

Prefer a fixed ZIP timestamp such as:

```text
1980-01-01 00:00:00
```

because ZIP cannot represent arbitrary earlier timestamps.

Preserve the **file contents**, not original filesystem metadata.

The same source set should produce the same ZIP SHA-256 on a repeat run in the same implementation.

After creating each archive once, regenerate it independently into a temporary location and confirm the SHA-256 is identical.

Do not commit temporary copies.

---

# 9. Archive indexes

Create:

```text
docs/implementation-briefs/ARCHIVE.md
docs/audits/ARCHIVE.md
docs/benchmarks/ARCHIVE.md
```

Each index must state:

```text
purpose
archive filename
boundary: pre-1.0 development history
creation date
file count
archive SHA-256
path convention inside ZIP
immutability policy
how future archive batches should be handled
complete filename inventory
```

Use a concise readable format.

The filename inventory must allow a visitor to determine whether a historical file exists without extracting the ZIP.

For each inventory entry, include at least:

```text
filename/path
```

Optionally include a short category/type label where it materially aids discovery.

Do not duplicate the full classification rationale for every file; the classification report already owns that rationale.

Link from each `ARCHIVE.md` to:

```text
../audits/DOCUMENTATION-ARCHIVE-CLASSIFICATION-REVIEW.md
```

using the correct relative path for that directory.

---

# 10. Immutability policy

Each `ARCHIVE.md` must state clearly:

> The pre-1.0 ZIP is immutable once committed. Later archival batches must use a new version- or date-bounded archive rather than rewriting this ZIP.

Do not create a workflow that continually rewrites:

```text
pre-1.0-*.zip
```

after release.

---

# 11. Approved current-surface link rewrites

Implement the 10 approved rewrites from the classification audit.

The current-surface referring files are:

```text
docs/audits/codex-whole-product-security-audit.md
docs/audits/HSTS-POLICY-REVIEW.md
docs/audits/PUBLIC-REPOSITORY-PUBLICATION-SIGNOFF.md
docs/audits/RELEASE-READINESS-REVIEW.md
docs/audits/RESOURCE-MATRIX-HEADER-GEOMETRY-VERIFICATION.md
docs/BACKLOG.md
docs/benchmarks/BROWSER-STORAGE-CAPACITY-BENCHMARK.md
docs/benchmarks/CLOUDFLARE-STAGING-SMOKE-TEST.md
docs/DEPLOYMENT.md
```

There are 10 archived-target/referring-file pairs because `RELEASE-READINESS-REVIEW.md` has two.

Use the exact mapping in the classification report.

Principles:

```text
prefer the current governing durable document
otherwise link to the relevant ARCHIVE.md index
never link directly into ZIP contents
do not alter historical meaning beyond replacing the stale/superseded link
```

---

# 12. Exact rewrite guidance

Apply the audit's mapping:

1. `docs/audits/codex-whole-product-security-audit.md`
   - replace the loose `BROWSER-STORAGE-RECOVERY-PROBE.md` dependency with the current Architecture storage/recovery section;
   - retain the current capacity benchmark where already relevant.

2. `docs/audits/HSTS-POLICY-REVIEW.md`
   - replace the implementation-brief link with the implementation archive index.

3. `docs/audits/PUBLIC-REPOSITORY-PUBLICATION-SIGNOFF.md`
   - replace the publication-signoff implementation-brief link with the implementation archive index.

4. `docs/audits/RELEASE-READINESS-REVIEW.md`
   - replace the reference-data caching review link with current Architecture/Deployment cache policy and/or the audit archive index as appropriate;
   - replace its implementation-brief link with the implementation archive index.

5. `docs/audits/RESOURCE-MATRIX-HEADER-GEOMETRY-VERIFICATION.md`
   - replace the archived heading-editorial-review link with `CROSS-LOCALE-COMPACT-COPY-AND-VISUAL-STATE-REVIEW.md` where that current evidence is the real successor, otherwise the audit archive index.

6. `docs/BACKLOG.md`
   - replace the non-final whole-product accessibility audit link with `codex-whole-product-accessibility-audit-final.md`.

7. `docs/benchmarks/BROWSER-STORAGE-CAPACITY-BENCHMARK.md`
   - replace the recovery-probe link with the current Architecture storage/recovery section.

8. `docs/benchmarks/CLOUDFLARE-STAGING-SMOKE-TEST.md`
   - replace the archived production-hosting-readiness link with `docs/DEPLOYMENT.md` and/or the current Cloudflare evidence as context requires.

9. `docs/DEPLOYMENT.md`
   - replace the production-hosting-readiness link with current deployment/self-owned wording and current Cloudflare smoke/header evidence.

Keep edits as small as possible.

---

# 13. Historical links inside archives

Do **not** rewrite links inside files that are themselves being archived.

Their relative historical graph should remain intact after extraction wherever those links originally targeted another archived file in the same category.

Cross-category historical links may no longer resolve automatically after extracting only one ZIP. This is acceptable historical preservation.

Do not mutate archived bytes to repair such links.

The archive indexes are the discovery surface for current visitors.

---

# 14. Remove archived loose files

After verifying the ZIP contents against source bytes, remove the archived loose files from the working tree.

This should appear to Git as:

```text
deleted historical Markdown files
added ZIP archives
added ARCHIVE.md indexes
small edits to retained loose documents
```

Do not leave duplicate loose copies of archived files.

Do not delete kept files.

---

# 15. Classification report remains loose

Preserve:

```text
docs/audits/DOCUMENTATION-ARCHIVE-CLASSIFICATION-REVIEW.md
```

as the durable rationale and classification record.

Do not put it in the superseded-audits ZIP.

This file should remain directly readable in the public repository.

---

# 16. Verify exact archive membership

For each ZIP, produce and compare a machine-readable inventory against the approved classification set.

Confirm:

```text
implementation archive:
  expected historical briefs only
  plus this implementation brief if present under docs/implementation-briefs/

audit archive:
  exactly the 46 classified superseded audits

benchmark archive:
  exactly the 2 classified superseded/exploratory benchmarks
```

Confirm no kept file appears inside a ZIP.

Confirm no classified archive file remains loose afterward.

Confirm every archived source file appears exactly once in its archive.

---

# 17. Verify archived bytes

For every archived entry:

1. compute the source file SHA-256 before deletion;
2. extract/read the corresponding ZIP entry;
3. compute the entry SHA-256;
4. require exact equality.

Report:

```text
N/N archived entries byte-identical
```

Do not rely only on ZIP CRC.

---

# 18. ZIP-level verification

For each ZIP record:

```text
filename
file count
compressed size
uncompressed size
SHA-256
deterministic rebuild SHA-256
```

The two SHA-256 values must match.

If deterministic rebuild differs, stop and investigate metadata/order/compression variance.

---

# 19. Current-link verification

After removing loose files and performing approved rewrites, search all retained/current Markdown for links to:

```text
docs/implementation-briefs/<archived-file>
docs/audits/<archived-file>
docs/benchmarks/<archived-file>
```

No current loose file should contain a direct Markdown link to a removed loose historical file.

Links in archived ZIP contents do not count.

Also check Markdown relative links in:

```text
README.md
AGENTS.md
docs/*.md
docs/localization/
all retained loose audits
all retained loose benchmarks
```

Do not attempt to validate external URLs in this task.

---

# 20. Current loose documentation surface

After implementation, the classified loose historical/release surface should contain:

```text
1 other benchmark
14 retained audits including the classification report
6 retained benchmark-directory files
3 ARCHIVE.md indexes
3 ZIP archives
```

Implementation briefs should contain no loose historical briefs once this task brief has been archived.

The exact directory entry totals may also include non-classified files if any exist; report them separately rather than forcing the count.

---

# 21. Public usability

Inspect the resulting directories as a visitor would see them.

Expected result:

```text
docs/implementation-briefs/
  ARCHIVE.md
  pre-1.0-implementation-history.zip

docs/audits/
  ARCHIVE.md
  pre-1.0-superseded-audits.zip
  <small current audit/evidence set>

docs/benchmarks/
  ARCHIVE.md
  pre-1.0-superseded-benchmarks.zip
  <small current benchmark/evidence set>
```

A visitor should not need to navigate hundreds of transitional Markdown files.

---

# 22. README / main documentation

Do not add a large new README section just to announce the archive.

If README or a durable maintainer document already has a documentation map where a concise archive-history pointer naturally belongs, a one-line pointer to the archive indexes is permitted.

Otherwise leave README unchanged.

Do not turn archival mechanics into prominent end-user documentation.

---

# 23. `.gitattributes` and binary treatment

Inspect the existing `.gitattributes`.

If ZIP files are not already treated safely as binary and Git could attempt text diffing, add only the minimal rule needed, for example:

```text
*.zip binary
```

Do not alter unrelated attributes.

If existing Git behavior is already appropriate, leave `.gitattributes` unchanged.

Record the decision.

---

# 24. Security/privacy sanity check

Before committing archive ZIPs, inspect the archived source set for unexpected newly introduced files relative to the classification audit.

Do not perform a new whole-history secret audit.

However, ensure:

```text
only the explicitly classified Markdown historical files are included
no .env
no .local-work
no game binaries
no exports/saves
no downloaded legal files
no temporary files
no machine-specific build artefacts
```

The archive should not broaden publication scope beyond documents already tracked and already approved for publication.

---

# 25. No history rewrite

Do not:

```text
git filter-repo
git filter-branch
rebase old history
remove historical blobs from Git history
rewrite commit authorship
rewrite past commits
```

The archive is current-tree curation only.

---

# 26. No application/release behavior changes

Do not modify:

```text
src/
scripts/
public/
reference-source/
package.json
package-lock.json
vite config
ESLint config
version metadata
application code
tests
localization catalogues
reference data
deployment behavior
DNS
Cloudflare settings
GitHub settings
```

except `.gitattributes` if the narrow ZIP-binary rule is actually needed.

---

# 27. Verification commands

At minimum run:

```sh
git diff --check
git status --short
```

Also run the archive-specific verification you implement for:

```text
membership
counts
entry SHA-256 equality
ZIP SHA-256
deterministic rebuild
current loose link integrity
kept-file exclusion
archived-file loose absence
```

A full application test/build suite is not required because this task changes documentation/archive packaging only.

If any application/source file changes unexpectedly, stop and investigate.

---

# 28. Expected diff classes

The final diff may contain only:

```text
deleted archived historical Markdown documents

added:
  docs/implementation-briefs/ARCHIVE.md
  docs/implementation-briefs/pre-1.0-implementation-history.zip
  docs/audits/ARCHIVE.md
  docs/audits/pre-1.0-superseded-audits.zip
  docs/benchmarks/ARCHIVE.md
  docs/benchmarks/pre-1.0-superseded-benchmarks.zip

small approved link rewrites in retained docs

optional minimal .gitattributes ZIP-binary rule
```

The classification report remains present and loose.

---

# 29. Stop conditions

Stop and report rather than improvising if:

```text
current tracked file inventory differs materially from the classification audit
a classified keep file would be archived by the generated set
a classified archive file is missing
a current loose file has an unresolved dependency on an archived file with no suitable rewrite
archived entry bytes differ from source bytes
deterministic rebuild hash differs
archive membership/count differs from approved set
unexpected non-Markdown material appears in the archive source set
```

Do not silently broaden or narrow the archive set.

---

# 30. Completion report

Report:

1. baseline branch/commit;
2. whether this implementation brief was present in-repo and archived;
3. final implementation archive count;
4. final audit archive count;
5. final benchmark archive count;
6. each ZIP SHA-256;
7. deterministic rebuild result for each ZIP;
8. archived-entry byte equality totals;
9. `ARCHIVE.md` paths;
10. retained loose audit count;
11. retained loose benchmark count;
12. retained implementation-brief loose count;
13. link rewrites performed;
14. unresolved current links, expected `0`;
15. whether `.gitattributes` changed and why;
16. confirmation classification report remains loose;
17. `git diff --check`;
18. `git status --short`;
19. confirmation no application/version/test/reference behavior changed;
20. confirmation no commit/push/tag/deploy/DNS/indexing/publication action occurred.

Suggested commit after maintainer review:

```text
docs: archive pre-1.0 development history
```

---

# Acceptance condition

This task is ready for maintainer review only if:

```text
all classified historical files are preserved byte-for-byte in the correct ZIP
all classified keep files remain loose
classification report remains loose
archive inventories are complete
ZIP hashes are recorded
ZIPs rebuild deterministically
current loose links do not point at removed loose files
no application/release behavior changed
```
